package com.syncronys.registration.client.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tmp_med_claims_client_temp")
public class ClientUser {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Client_SSN")
    private String ssn;

    @Column(name = "Client_First_Name")
    private String firstName;

    @Column(name = "Client_Last_Name")
    private String lastName;


    @Column(name = "Client_DOB")
    private LocalDate dob;

}
