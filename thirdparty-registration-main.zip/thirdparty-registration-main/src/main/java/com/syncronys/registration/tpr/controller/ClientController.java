package com.syncronys.registration.tpr.controller;

import com.syncronys.registration.tpr.dto.ClientDto;
import com.syncronys.registration.tpr.dto.EMail;
import com.syncronys.registration.tpr.service.ClientService;
import com.syncronys.registration.tpr.service.EmailService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.security.Principal;
import java.util.List;

@Controller
public class ClientController {

    private ClientService clientService;

    private EmailService emailService;

    public ClientController(ClientService clientService, EmailService emailService) {
        this.clientService = clientService;
        this.emailService = emailService;
    }


    // handler method to handle user registration request
    @GetMapping("client-register")
    public String showRegistrationForm(Model model) {
        ClientDto client = new ClientDto();
        model.addAttribute("client", client);
        return "client-register";
    }

    // handler method to handle register user form submit request
    @PostMapping("/client-register/save")
    public String registration(@Valid @ModelAttribute("client") ClientDto client,
                               BindingResult result,
                               Model model) {
        if (result.hasErrors()) {
            model.addAttribute("client", client);
            return "client-register";
        }
        try {
            clientService.saveClient(client);
            EMail email = new EMail();
            email.setTo("smaddirala@syncronys.org");
            email.setFrom("smaddirala@syncronys.org");
            email.setSubject("Testing");
            email.setContent("test");
            email.getProps().put("name","vsr");
            email.getProps().put("sign","vsr");
            email.getProps().put("location", "us");
            emailService.sendEmail(email);
        } catch (IllegalArgumentException e) {
            return "redirect:/client-register?error=" + e.getMessage();
        } catch (Exception e) {
            return "redirect:/client-register?error=" + e.getMessage();
        }
        return "redirect:/client-register?success";
    }

    @GetMapping("/clients")
    public String listRegisteredUsers(Model model) {
        List<ClientDto> clients = clientService.findAllClients();
        model.addAttribute("clients", clients);
        return "clients";
    }

    @GetMapping("/client-info")
    public String clientInfo(Model model, @RequestParam("clientId") String clientId) {
        ClientDto clientDto = new ClientDto();
        clientDto.setId(Long.valueOf(clientId));
        ClientDto client = clientService.findByClient(clientDto);
        client.setBtnName("Approved".equals(client.getStatus()) ? "Deny" : "Approve");
        client.setStatus("Approved".equals(client.getStatus()) ? "Deny" : "Approved");
        model.addAttribute("client", client);
        return "client-info";
    }

    @PostMapping("/client/update")
    public String update(@ModelAttribute("client") ClientDto client, Model model) {
        try {
            clientService.updateClient(client);
            model.addAttribute("client", client);
        } catch (Exception e) {
            return "redirect:/client-info?error=" + e.getMessage() + "&clientId=" + client.getId();
        }
        return "redirect:/client-info?success" + "&clientId=" + client.getId();
    }
}
