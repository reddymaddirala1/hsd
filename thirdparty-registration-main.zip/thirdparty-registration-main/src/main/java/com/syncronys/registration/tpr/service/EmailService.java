package com.syncronys.registration.tpr.service;

import com.syncronys.registration.tpr.dto.EMail;

public interface EmailService {
    void sendEmail(EMail mail);
}
